/*
 * map module
 */
jQuery(function($){
    var ToolBarMD = Spine.ToolBarMD = Spine.Model.setup("ToolBarMD",[]);

    ToolBarMD.extend(Spine.Model.Local) ;
});
