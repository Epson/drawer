/*
 * map module
 */
jQuery(function($){
    var shapesMD = Spine.shapesMD = Spine.Model.setup("shapesMD",[]);

    shapesMD.extend(Spine.Model.Local) ;
});
